#ifndef J_PIECE_H
#define J_PIECE_H

#include "tetromino.h"

namespace Tetris {

class J_piece : public Tetromino
{
public:
    J_piece():Tetromino(){}
    ~J_piece(){}

    char* getTetromino() {strcpy(Tetromino::tetromino, "  o   o  oo     "); return Tetromino::tetromino;}
    TetrominoID getID() {return TETRIS_J_PIECE;}
};

}

#endif // J_PIECE_H
