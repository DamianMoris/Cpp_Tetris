#ifndef J_PIECE_H
#define J_PIECE_H

#include "tetromino.h"

namespace Tetris {

class J_piece : public Tetromino
{
public:
    J_piece():Tetromino(){}

    const char* getTetromino() {strcpy(Tetromino::tetromino, "  o   o  oo     "); return Tetromino::tetromino;}

    TetrominoID getID() {return TETRIS_J_PIECE;}

//    unsigned char tetromino[16] = {' ' ,'o' ,' ' ,' ',
//                                   ' ' ,'o' ,' ' ,' ',
//                                   'o' ,'o' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

}

#endif // J_PIECE_H
