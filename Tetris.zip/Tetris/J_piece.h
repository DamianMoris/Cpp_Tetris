#ifndef J_PIECE_H
#define J_PIECE_H

#include "tetromino.h"

class J_piece : public Tetromino
{
public:
    unsigned char tetromino[16] = {' ' ,'o' ,' ' ,' ',
                                   ' ' ,'o' ,' ' ,' ',
                                   'o' ,'o' ,' ' ,' ',
                                   ' ' ,' ' ,' ' ,' '};
};

#endif // J_PIECE_H
