#ifndef O_PIECE_H
#define O_PIECE_H

#include "tetromino.h"

namespace Tetris {

class O_piece : public Tetromino
{
public:
    O_piece():Tetromino(){}

    char* getTetromino() {strcpy(Tetromino::tetromino, "     oo  oo     "); return Tetromino::tetromino;}

    TetrominoID getID() {return TETRIS_O_PIECE;}

//    unsigned char tetromino[16] = {'o' ,'o' ,' ' ,' ',
//                                   'o' ,'o' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

}

#endif // O_PIECE_H
