#include <iostream>
#include "game.h"
#include "tetromino.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

using namespace Tetris;

int main()
{
    srand((unsigned int) time(NULL));
    Game fGame;
    Tetromino Tetr;

    Tetr.getRandomTetromino();

//    I_piece I;
//    J_piece J;
//    L_piece L;
//    O_piece O;
//    S_piece S;
//    T_piece T;
//    Z_piece Z;
//    Tetromino * TI = &I;
//    Tetromino * TJ = &J;
//    Tetromino * TL = &L;
//    Tetromino * TO = &O;
//    Tetromino * TS = &S;
//    Tetromino * TT = &T;
//    Tetromino * TZ = &Z;

//    I.getTetromino();
//    TI->printTetromino();

//    J.getTetromino();
//    TJ->printTetromino();

//    L.getTetromino();
//    TL->printTetromino();

//    O.getTetromino();
//    TO->printTetromino();

//    S.getTetromino();
//    TS->printTetromino();

//    T.getTetromino();
//    TT->printTetromino();

//    Z.getTetromino();
//    TZ->printTetromino();

//    std::cout << I.getID();
//    std::cout << J.getID();
//    std::cout << L.getID();
//    std::cout << O.getID();
//    std::cout << S.getID();
//    std::cout << T.getID();
//    std::cout << Z.getID();

    fGame.printGame();
    return 0;
}

