#include <iostream>
#include "game.h"
#include "tetromino.h"

int main()
{
    srand((unsigned int) time(NULL));
    Game fGame;
    fGame.printGame();

    return 0;
}
