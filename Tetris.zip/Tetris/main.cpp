#include <iostream>
#include "game.h"
#include "tetromino.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

using namespace Tetris;

int main()
{
    srand((unsigned int) time(NULL));
    Game fGame;
    //Tetromino Tetr;

    Tetromino* currentTetromino = fGame.getRandomTetromino();

    fGame.printGame(currentTetromino);
    return 0;
}
