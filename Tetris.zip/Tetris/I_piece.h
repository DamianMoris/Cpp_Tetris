#ifndef I_PIECE_H
#define I_PIECE_H

#include "tetromino.h"

class I_piece : public Tetromino
{
public:
    const char* getTetromino() {return ("o   o   o   o   ");}


    /*
    char* getTetromino() { tetromino[] = {'o' ,' ' ,' ' ,' ',
                                   'o' ,' ' ,' ' ,' ',
                      w             'o' ,' ' ,' ' ,' ',
                                   'o' ,' ' ,' ' ,' '}; return tetromino;}*/
};

#endif // I_PIECE_H
