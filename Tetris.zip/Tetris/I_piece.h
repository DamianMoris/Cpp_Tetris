#ifndef I_PIECE_H
#define I_PIECE_H

#include "tetromino.h"
#include <cstring>

class I_piece : public Tetromino
{
public:
    I_piece():Tetromino(){}

    const char* getTetromino() {strcpy(Tetromino::tetromino, "o   "
                                                             "o   "
                                                             "o   "
                                                             "o   ");
                                                             return tetromino;}



//    getTetromino() { tetromino[] = {'o' ,' ' ,' ' ,' ',
//                                    'o' ,' ' ,' ' ,' ',
//                                    'o' ,' ' ,' ' ,' ',
//                                    'o' ,' ' ,' ' ,' '}; return tetromino;}
};

#endif // I_PIECE_H
