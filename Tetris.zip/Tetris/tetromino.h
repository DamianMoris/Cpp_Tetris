#ifndef TETROMINO_H
#define TETROMINO_H

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cstring>
#include "tetrominoid.h"

class Tetromino
{
    friend class Game;
public:

    char tetromino[17] = "oooooooooooooooo";
    //unsigned char getTetrominoID() {return rand() % 7;};
    const char* getTetromino(void) const;
    void getRandomTetromino(void) const;
    void printTetromino();
    void rotateTetromino();
    void insertTetromino();
    TetrominoID getID() const {return(ID);}
    TetrominoID ID;

    unsigned char Xpos = 0;
    unsigned char Ypos = 0;

private:
    void setID(const TetrominoID ID) {this->ID = ID;}

};

#endif // TETROMINO_H
