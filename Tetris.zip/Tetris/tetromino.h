#ifndef TETROMINO_H
#define TETROMINO_H

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cstring>
#include "tetrominoid.h"

namespace Tetris {

class Tetromino
{
    //friend class Game;
public:
    Tetromino():Xpos(0), Ypos(0){}

    char tetromino[17] = "oooooooooooooooo";
    virtual char* getTetromino(void) = 0;
    void printTetromino(void);
    void rotateTetromino(void);
    void insertTetromino(void);
    TetrominoID getID() const {return(ID);}
    TetrominoID ID;

    unsigned char Xpos;
    unsigned char Ypos;

private:
    void setID(const TetrominoID ID) {this->ID = ID;}
};

}

#endif // TETROMINO_H
