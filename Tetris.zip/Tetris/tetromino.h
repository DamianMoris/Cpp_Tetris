#ifndef TETROMINO_H
#define TETROMINO_H

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "tetrominoid.h"

class Tetromino
{
    friend class Game;
public:
    Tetromino();

    //unsigned char shape;
    char tetromino[16];
    //unsigned char getTetrominoID() {return rand() % 7;};
    const char* getTetromino( void ) const;
    void printTetromino();
    void rotateTetromino();
    void insertTetromino();
    //unsigned char ID = getTetrominoID();
    TetrominoID getID() const { return( ID ); }
    TetrominoID ID;

};

#endif // TETROMINO_H
