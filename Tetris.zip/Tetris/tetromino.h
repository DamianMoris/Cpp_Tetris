#ifndef TETROMINO_H
#define TETROMINO_H

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <cstring>
#include "tetrominoid.h"

class Tetromino
{
    friend class Game;
public:

    char tetromino[17] = "oooooooooooooooo";
    //unsigned char getTetrominoID() {return rand() % 7;};
    virtual char* getTetromino(void) = 0;
    void getRandomTetromino(void) const;
    void printTetromino(void);
    void rotateTetromino(void);
    void insertTetromino(void);
    TetrominoID getID() const {return(ID);}
    TetrominoID ID;

    unsigned char Xpos = 0;
    unsigned char Ypos = 0;

private:
    void setID(const TetrominoID ID) {this->ID = ID;}

};

#endif // TETROMINO_H
