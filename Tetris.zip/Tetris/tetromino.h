#ifndef TETROMINO_H
#define TETROMINO_H

#include <iostream>
#include <stdlib.h>
#include <time.h>

class Tetromino
{
    friend class Game;
    friend class I_piece;
    friend class J_piece;
    friend class L_piece;
    friend class O_piece;
    friend class S_piece;
    friend class T_piece;
    friend class Z_piece;
public:
    unsigned char shape;
    char tetromino[16];
    unsigned char getTetrominoID() {return rand() % 7;};
    const char* getTetromino(unsigned char getTetrominoID());
    void rotateTetromino();
    void insertTetromino();
};

#endif // TETROMINO_H
