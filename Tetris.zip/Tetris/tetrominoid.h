#ifndef TETROMINOID_H
#define TETROMINOID_H

namespace Tetris {

enum TetrominoID
{
    TETRIS_I_PIECE,
    TETRIS_J_PIECE,
    TETRIS_L_PIECE,
    TETRIS_O_PIECE,
    TETRIS_S_PIECE,
    TETRIS_T_PIECE,
    TETRIS_Z_PIECE
};

}

#endif // TETROMINOID_H
