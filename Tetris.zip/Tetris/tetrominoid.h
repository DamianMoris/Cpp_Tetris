#ifndef TETROMINOID_H
#define TETROMINOID_H

enum TetrominoID
{
    I_PIECE,
    J_PIECE,
    L_PIECE,
    O_PIECE,
    S_PIECE,
    T_PIECE,
    Z_PIECE
};

#endif // TETROMINOID_H
