#ifndef S_PIECE_H
#define S_PIECE_H

#include "tetromino.h"

namespace Tetris {

class S_piece : public Tetromino
{
public:
    S_piece():Tetromino(){}
    ~S_piece(){}

    char* getTetromino() {strcpy(Tetromino::tetromino, "     oo oo      "); return Tetromino::tetromino;}
    TetrominoID getID() {return TETRIS_S_PIECE;}
};

}

#endif // S_PIECE_H
