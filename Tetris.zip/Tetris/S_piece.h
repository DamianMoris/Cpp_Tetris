#ifndef S_PIECE_H
#define S_PIECE_H

#include "tetromino.h"

class S_piece : public Tetromino
{
public:
    S_piece():Tetromino(){}
//    unsigned char tetromino[16] = {' ' ,'o' ,'o' ,' ',
//                                   'o' ,'o' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

#endif // S_PIECE_H
