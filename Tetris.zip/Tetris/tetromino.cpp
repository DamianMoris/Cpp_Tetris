#include <cstring>
#include "tetromino.h"
#include "game.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

using namespace Tetris;

void Tetromino::insertTetromino()
{
    Game fGame;
    //strcpy(tetromino, getTetromino());

    for(unsigned char i = 0; i < 4; i++)
    {
        for(unsigned char j = 0; j < 4; j++)
        {
            fGame.game[ROWS / 2 - 1 + i + j * ROWS] = Tetromino::tetromino[i + j * ROWS];
        }
    }
}

void Tetromino::printTetromino()
{
    for(unsigned char i = 0; i < 4; i++)
    {
        for(unsigned char j = 0; j < 4; j++)
        {
            std::cout << Tetromino::tetromino[i * 4 + j];
        }
        std::cout << "\n";
    }
}
