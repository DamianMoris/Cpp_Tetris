#include <cstring>
#include "tetromino.h"
#include "game.h"

void Tetromino::insertTetromino()
{
    Game fGame;
    //strcpy(tetromino, getTetromino());

    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            fGame.game[ROWS / 2 - 1 + i + j * ROWS] = tetromino[i + j * ROWS];
        }
    }
}

char* Tetromino::getTetromino(unsigned char ID)
{

    return
}
