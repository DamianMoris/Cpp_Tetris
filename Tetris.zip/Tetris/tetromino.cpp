#include <cstring>
#include "tetromino.h"
#include "game.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

void Tetromino::insertTetromino()
{
    Game fGame;
    //strcpy(tetromino, getTetromino());

    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            fGame.game[ROWS / 2 - 1 + i + j * ROWS] = tetromino[i + j * ROWS];
        }
    }
}

/*
void Tetromino::getTetromino()
{
    switch (getID())
    {
        case I_PIECE:
        {
            I_piece I;
        }
        case J_PIECE:
        {
            J_piece J;
        }
        case L_PIECE:
        {
            L_piece L;
        }
        case O_PIECE:
        {
            O_piece O;
        }
        case S_PIECE:
        {
            S_piece S;
        }
        case T_PIECE:
        {
            T_piece T;
        }
        case Z_PIECE:
        {
            Z_piece Z;
        }
        default:
        {
            break;
        }
    }
}*/
