#include <cstring>
#include "tetromino.h"
#include "game.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

void Tetromino::insertTetromino()
{
    Game fGame;
    //strcpy(tetromino, getTetromino());

    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            fGame.game[ROWS / 2 - 1 + i + j * ROWS] = Tetromino::tetromino[i + j * ROWS];
        }
    }
}

void Tetromino::printTetromino()
{
    for(int i = 0; i < 4; i++)
    {
        for(int j = 0; j < 4; j++)
        {
            std::cout << Tetromino::tetromino[i * 4 + j];
        }
        std::cout << "\n";
    }
}


void Tetromino::getRandomTetromino() const
{
    Tetris::I_piece I;
    Tetris::J_piece J;
    Tetris::L_piece L;
    Tetris::O_piece O;
    Tetris::S_piece S;
    Tetris::T_piece T;
    Tetris::Z_piece Z;
    Tetromino * TI = &I;
    Tetromino * TJ = &J;
    Tetromino * TL = &L;
    Tetromino * TO = &O;
    Tetromino * TS = &S;
    Tetromino * TT = &T;
    Tetromino * TZ = &Z;

    switch (rand() % 7)
    {
        case TETRIS_I_PIECE:
        {
            I.getTetromino();
            TI->printTetromino();
            break;
        }
        case TETRIS_J_PIECE:
        {
            J.getTetromino();
            TJ->printTetromino();
            break;
        }
        case TETRIS_L_PIECE:
        {
            L.getTetromino();
            TL->printTetromino();
            break;
        }
        case TETRIS_O_PIECE:
        {
            O.getTetromino();
            TO->printTetromino();
            break;
        }
        case TETRIS_S_PIECE:
        {
            S.getTetromino();
            TS->printTetromino();
            break;
        }
        case TETRIS_T_PIECE:
        {
            T.getTetromino();
            TT->printTetromino();
            break;
        }
        case TETRIS_Z_PIECE:
        {
            Z.getTetromino();
            TZ->printTetromino();
            break;
        }
        default:
        {
            break;
        }
    }
}
