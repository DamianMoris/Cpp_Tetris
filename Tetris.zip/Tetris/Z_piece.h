#ifndef Z_PIECE_H
#define Z_PIECE_H

#include "tetromino.h"

namespace Tetris {

class Z_piece : public Tetromino
{
public:
    Z_piece():Tetromino(){}
    ~Z_piece(){}

private:
    char* getTetromino() {strcpy(Tetromino::tetromino, "    oo   oo     "); return Tetromino::tetromino;}
    TetrominoID getID() {return TETRIS_Z_PIECE;}
};

}

#endif // Z_PIECE_H
