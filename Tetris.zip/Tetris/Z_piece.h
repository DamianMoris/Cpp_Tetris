#ifndef Z_PIECE_H
#define Z_PIECE_H

#include "tetromino.h"

namespace Tetris {

class Z_piece : public Tetromino
{
public:
    Z_piece():Tetromino(){}

    const char* getTetromino() {strcpy(Tetromino::tetromino, "    oo   oo     "); return Tetromino::tetromino;}

    TetrominoID getID() {return TETRIS_Z_PIECE;}

//    unsigned char tetromino[16] = {'o' ,'o' ,' ' ,' ',
//                                   ' ' ,'o' ,'o' ,' ',
//                                   ' ' ,' ' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

}

#endif // Z_PIECE_H
