#ifndef Z_PIECE_H
#define Z_PIECE_H

#include "tetromino.h"

class Z_piece : public Tetromino
{
public:
    Z_piece():Tetromino(){}
//    unsigned char tetromino[16] = {'o' ,'o' ,' ' ,' ',
//                                   ' ' ,'o' ,'o' ,' ',
//                                   ' ' ,' ' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

#endif // Z_PIECE_H
