#include "game.h"
#include "tetromino.h"

void Game::printGame()
{
    Tetromino Tetr;
    Tetr.Xpos = Game::tetrominoStartX;
    Tetr.Ypos = Game::tetrominoStartY;
    Tetr.printTetromino();
    std::cout <<  "test1";
    std::cout <<  Game::tetrominoStartX;
    std::cout <<  Game::tetrominoStartY;
    std::cout <<  Tetr.Xpos;
    std::cout <<  Tetr.Ypos;

    for(unsigned char i = 0; i < ROWS; i++)
    {
        for(unsigned char j = 0; j < COLUMNS; j++)
        {
            if(j == 0 || j == COLUMNS - 1 || i == ROWS - 1) // check the boundaries of the game
            {
                game[i * ROWS + j] = 'O';
            }
            else
            {
                if(!strcmp(Tetr.tetromino, "oooooooooooooooo"))
                {
                    if(i == Tetr.Xpos && j == Tetr.Ypos)
                    {
                        game[i * ROWS + j++] = Tetr.tetromino[Tetr.Xpos++ * i + Tetr.Ypos];
                        game[i * ROWS + j++] = Tetr.tetromino[Tetr.Xpos++ * i + Tetr.Ypos];
                        game[i * ROWS + j++] = Tetr.tetromino[Tetr.Xpos++ * i + Tetr.Ypos];
                        game[i * ROWS + j] = Tetr.tetromino[Tetr.Xpos * i + Tetr.Ypos];
                        Tetr.Ypos++;
                    }
                    else
                    {
                        game[i * ROWS + j] = ' ';
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }
    std::cout <<  "test2";
    std::cout <<  Tetr.Xpos;
    std::cout <<  Tetr.Ypos;

    std::cout << "\n\n\n";

    for(unsigned char i = 0; i < ROWS; i++) // print the game
    {
        std::cout << '\t';
        for(unsigned char j = 0; j < COLUMNS; j++)
        {
            std::cout << game[i * ROWS + j];
        }
        std::cout << '\n';
    }
}
