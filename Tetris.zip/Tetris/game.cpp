#include "game.h"

void Game::printGame()
{

    for(int i = 0; i < ROWS; i++)
    {
        for(int j = 0; j < COLUMNS; j++)
        {
            if(j == 0 || j == COLUMNS - 1 || i == ROWS - 1) // check the boundaries of the game
            {
                game[i * ROWS + j] = 'O';
            }
            else
            {
                if(game[i * ROWS + j] != 'o')
                game[i * ROWS + j] = ' ';
            }
        }
    }

    std::cout << "\n\n\n";

    for(int i = 0; i < ROWS; i++) // print the game
    {
        std::cout << '\t';
        for(int j = 0; j < COLUMNS; j++)
        {
            std::cout << game[i * ROWS + j];
        }
        std::cout << '\n';
    }
}
