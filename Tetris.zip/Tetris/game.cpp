#include "game.h"
#include "tetromino.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

using namespace Tetris;

void Game::printGame(Tetromino* Tetr)
{
    for(unsigned char i = 0; i < ROWS; i++)
    {
        for(unsigned char j = 0; j < COLUMNS; j++)
        {
            if(j == 0 || j == COLUMNS - 1 || i == ROWS - 1) // check the boundaries of the game
            {
                game[i * ROWS + j] = 'O'; // boundaries of game are represented by 'O'
            }
            else
            {
                if(strcmp(Tetr->tetromino, "oooooooooooooooo") != 0 && Tetr != nullptr) // check if tetromino array doesnt contain the initial value
                {
                    if((i == tetrominoStartY || i == tetrominoStartY + 1 || i == tetrominoStartY + 2 || i == tetrominoStartY + 3) && j == tetrominoStartX) // check the position in game array to insert tetromino array in the middle on top
                    {
                        game[i * ROWS + j] = Tetr->tetromino[Tetr->Ypos * 4 + Tetr->Xpos];        // insert first element of a row of tetromino array into game array
                        game[i * ROWS + ++j] = Tetr->tetromino[Tetr->Ypos * 4 + ++Tetr->Xpos];    // insert second element of a row of tetromino array into game array
                        game[i * ROWS + ++j] = Tetr->tetromino[Tetr->Ypos * 4 + ++Tetr->Xpos];    // insert third element of a row of tetromino array into game array
                        game[i * ROWS + ++j] = Tetr->tetromino[Tetr->Ypos * 4 + ++Tetr->Xpos];    // insert fourth element of a row of tetromino array into game array
                        Tetr->Ypos++;
                        Tetr->Xpos = 0;
                    }
                    else
                    {
                        game[i * ROWS + j] = ' '; // empty space of game (not boundaries and not tetromino pieces) are represented by ' '
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }

    std::cout << '\n';
    for(unsigned char i = 0; i < ROWS; i++) // print the game
    {
        std::cout << '\t';
        for(unsigned char j = 0; j < COLUMNS; j++)
        {
            std::cout << game[i * ROWS + j];
        }
        std::cout << '\n';
    }
    std::cout << '\n';
}

Tetromino* Game::getRandomTetromino() const
{
    switch (rand() % 7)
    {
        case TETRIS_I_PIECE:
        {
            Tetromino* TI = new Tetris::I_piece(); // DONT FORGET TO DELETE !!!!!
            TI->getTetromino();
            return TI;
        }
        case TETRIS_J_PIECE:
        {
            Tetromino* TJ = new Tetris::J_piece(); // DONT FORGET TO DELETE !!!!!
            TJ->getTetromino();
            return TJ;
        }
        case TETRIS_L_PIECE:
        {
            Tetromino* TL = new Tetris::L_piece(); // DONT FORGET TO DELETE !!!!!
            TL->getTetromino();
            return TL;
        }
        case TETRIS_O_PIECE:
        {
            Tetromino* TO = new Tetris::O_piece(); // DONT FORGET TO DELETE !!!!!
            TO->getTetromino();
            return TO;
        }
        case TETRIS_S_PIECE:
        {
            Tetromino* TS = new Tetris::S_piece(); // DONT FORGET TO DELETE !!!!!
            TS->getTetromino();
            return TS;
        }
        case TETRIS_T_PIECE:
        {
            Tetromino* TT = new Tetris::T_piece(); // DONT FORGET TO DELETE !!!!!
            TT->getTetromino();
            return TT;
        }
        case TETRIS_Z_PIECE:
        {
            Tetromino* TZ = new Tetris::Z_piece(); // DONT FORGET TO DELETE !!!!!
            TZ->getTetromino();
            return TZ;
        }
        default:
        {
            return nullptr; // shouldnt be able to happen, but if it does, returns nullptr
        }
    }
}
