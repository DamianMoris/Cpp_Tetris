#include "game.h"
#include "tetromino.h"
#include "I_piece.h"
#include "J_piece.h"
#include "L_piece.h"
#include "O_piece.h"
#include "S_piece.h"
#include "T_piece.h"
#include "Z_piece.h"

using namespace Tetris;

void Game::printGame(Tetromino* Tetr)
{
    Tetr->printTetromino();
    std::cout <<  "test1\n";
    std::cout <<  "X:" << Tetr->Xpos << " Y:" << Tetr->Ypos << '\n';

    for(unsigned char i = 0; i < ROWS; i++)
    {
        for(unsigned char j = 0; j < COLUMNS; j++)
        {
            if(j == 0 || j == COLUMNS - 1 || i == ROWS - 1) // check the boundaries of the game
            {
                game[i * ROWS + j] = 'O';
            }
            else
            {
                if(strcmp(Tetr->tetromino, "oooooooooooooooo") != 0)
                {
                    if((i == tetrominoStartY || i == tetrominoStartY + 1 || i == tetrominoStartY + 2 || i == tetrominoStartY + 3) && j == tetrominoStartX)
                    {
                        std::cout << "1: " <<  " X:" << Tetr->Xpos << " Y:" << Tetr->Ypos << " i:" << i << '\n';
                        game[i * ROWS + j] = Tetr->tetromino[Tetr->Ypos * 4 + Tetr->Xpos];
                        game[i * ROWS + ++j] = Tetr->tetromino[Tetr->Ypos * 4 + ++Tetr->Xpos];
                        game[i * ROWS + ++j] = Tetr->tetromino[Tetr->Ypos * 4 + ++Tetr->Xpos];
                        game[i * ROWS + ++j] = Tetr->tetromino[Tetr->Ypos * 4 + ++Tetr->Xpos];
                        std::cout << "2: " <<  " X:" << Tetr->Xpos << " Y:" << Tetr->Ypos << " i:" << i << '\n';
                        Tetr->Ypos++;
                        Tetr->Xpos = 0;
                        std::cout << "3: " <<  " X:" << Tetr->Xpos << " Y:" << Tetr->Ypos << " i:" << i << '\n';
                    }
                    else
                    {
                        game[i * ROWS + j] = ' ';
                    }
                }
                else
                {
                    break;
                }
            }
        }
    }
    std::cout <<  "test2\n\n\n";


    for(unsigned char i = 0; i < ROWS; i++) // print the game
    {
        std::cout << '\t';
        for(unsigned char j = 0; j < COLUMNS; j++)
        {
            std::cout << game[i * ROWS + j];
        }
        std::cout << '\n';
    }

    std::cout <<  "test3\n";
}

Tetromino* Game::getRandomTetromino() const
{
    switch (rand() % 7)
    {
        case TETRIS_I_PIECE:
        {
            Tetromino* TI = new Tetris::I_piece(); // DONT FORGET TO DELETE !!!!!
            TI->getTetromino();
            //TI->printTetromino();
            return TI;
        }
        case TETRIS_J_PIECE:
        {
            Tetromino* TJ = new Tetris::J_piece(); // DONT FORGET TO DELETE !!!!!
            TJ->getTetromino();
            //TJ->printTetromino();
            return TJ;
        }
        case TETRIS_L_PIECE:
        {
            Tetromino* TL = new Tetris::L_piece(); // DONT FORGET TO DELETE !!!!!
            TL->getTetromino();
            //TL->printTetromino();
            return TL;
        }
        case TETRIS_O_PIECE:
        {
            Tetromino* TO = new Tetris::O_piece(); // DONT FORGET TO DELETE !!!!!
            TO->getTetromino();
            //TO->printTetromino();
            return TO;
        }
        case TETRIS_S_PIECE:
        {
            Tetromino* TS = new Tetris::S_piece(); // DONT FORGET TO DELETE !!!!!
            TS->getTetromino();
            //TS->printTetromino();
            return TS;
        }
        case TETRIS_T_PIECE:
        {
            Tetromino* TT = new Tetris::T_piece(); // DONT FORGET TO DELETE !!!!!
            TT->getTetromino();
            //TT->printTetromino();
            return TT;
        }
        case TETRIS_Z_PIECE:
        {
            Tetromino* TZ = new Tetris::Z_piece(); // DONT FORGET TO DELETE !!!!!
            TZ->getTetromino();
            //TZ->printTetromino();
            return TZ;
        }
        default:
        {
            return nullptr;
        }
    }
}
