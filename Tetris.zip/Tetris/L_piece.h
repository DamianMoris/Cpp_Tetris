#ifndef L_PIECE_H
#define L_PIECE_H

#include "tetromino.h"

namespace Tetris {

class L_piece : public Tetromino
{
public:
    L_piece():Tetromino(){}
    ~L_piece(){}

private:
    char* getTetromino() {strcpy(Tetromino::tetromino, " o   o   oo     "); return Tetromino::tetromino;}
    TetrominoID getID() {return TETRIS_L_PIECE;}
};

}

#endif // L_PIECE_H
