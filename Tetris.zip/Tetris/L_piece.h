#ifndef L_PIECE_H
#define L_PIECE_H

#include "tetromino.h"

class L_piece : public Tetromino
{
public:
    L_piece():Tetromino(){}
//    unsigned char tetromino[16] = {'o' ,' ' ,' ' ,' ',
//                                   'o' ,' ' ,' ' ,' ',
//                                   'o' ,'o' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

#endif // L_PIECE_H
