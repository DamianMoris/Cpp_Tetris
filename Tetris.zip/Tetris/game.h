#ifndef GAME_H
#define GAME_H

#include <iostream>

#define ROWS 20 // for standard tetris 22
#define COLUMNS 14 // for standard tetris 12

class Game
{
    //friend class Tetromino;
public:
    unsigned char game[ROWS * COLUMNS];
    void printGame();

    unsigned char tetrominoStartX = ( COLUMNS - 1 ) / 2; // middle of the game
    unsigned char tetrominoStartY = 0;

};


#endif // GAME_H
