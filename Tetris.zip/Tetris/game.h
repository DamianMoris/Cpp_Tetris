#ifndef GAME_H
#define GAME_H

#include <iostream>
#include "tetromino.h"

#define ROWS 20 // for "standard" tetris 22
#define COLUMNS 14 // for "standard" tetris 12

namespace Tetris {

class Game
{
    //friend class Tetromino;
public:
    unsigned char game[ROWS * COLUMNS];
    void printGame(Tetromino*);
    Tetromino* getRandomTetromino(void) const;

    unsigned char tetrominoStartX = ( COLUMNS - 1 ) / 2; // middle of the game on imaginary "X-axis"
    unsigned char tetrominoStartY = 0;

};

}

#endif // GAME_H
