#ifndef GAME_H
#define GAME_H

#include <iostream>
#include "tetromino.h"

#define ROWS 20 // for "standard" tetris 22
#define COLUMNS 14 // for "standard" tetris 12

namespace Tetris {

class Game
{
public:
    Game():tetrominoStartX(((COLUMNS - 1) / 2) - 1), tetrominoStartY(0){}

    unsigned char game[ROWS * COLUMNS]; // stores the whole layout of the game in an array
    void printGame(Tetromino*);
    Tetromino* getRandomTetromino(void) const;

private:
    const unsigned char tetrominoStartX; // inserted value should approximately be the middle of the game on an imaginary "X-axis" (horizontal)
    const unsigned char tetrominoStartY;
};

}

#endif // GAME_H
