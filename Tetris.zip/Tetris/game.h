#ifndef GAME_H
#define GAME_H

#include <iostream>

#define ROWS 20 // for standard tetris 22
#define COLUMNS 14 // for standard tetris 12

class Game
{
public:
    unsigned char game[ROWS * COLUMNS];
    void printGame();

};


#endif // GAME_H
