#ifndef T_PIECE_H
#define T_PIECE_H

#include "tetromino.h"

namespace Tetris {

class T_piece : public Tetromino
{
public:
    T_piece():Tetromino(){}
    ~T_piece(){}

private:
    char* getTetromino() {strcpy(Tetromino::tetromino, "    ooo  o      "); return Tetromino::tetromino;}
    TetrominoID getID() {return TETRIS_T_PIECE;}
};

}

#endif // T_PIECE_H
