#ifndef T_PIECE_H
#define T_PIECE_H

#include "tetromino.h"

namespace Tetris {

class T_piece : public Tetromino
{
public:
    T_piece():Tetromino(){}

    char* getTetromino() {strcpy(Tetromino::tetromino, "    ooo  o      "); return Tetromino::tetromino;}

    TetrominoID getID() {return TETRIS_T_PIECE;}

//    unsigned char tetromino[16] = {'o' ,'o' ,'o' ,' ',
//                                   ' ' ,'o' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' ',
//                                   ' ' ,' ' ,' ' ,' '};
};

}

#endif // T_PIECE_H
