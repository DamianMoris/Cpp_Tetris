#ifndef T_PIECE_H
#define T_PIECE_H

#include "tetromino.h"

class T_piece : public Tetromino
{
public:
    unsigned char tetromino[16] = {'o' ,'o' ,'o' ,' ',
                                   ' ' ,'o' ,' ' ,' ',
                                   ' ' ,' ' ,' ' ,' ',
                                   ' ' ,' ' ,' ' ,' '};
};

#endif // T_PIECE_H
